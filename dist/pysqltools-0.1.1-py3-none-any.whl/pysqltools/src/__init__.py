"""
Source code for the pysqltools package
"""

from pysqltools.src.queries.queries import Query, SQLString
