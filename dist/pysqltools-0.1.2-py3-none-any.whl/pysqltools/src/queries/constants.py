"""
Constant values for the queries package
"""

KEYWORDS = ["select", "from", "where", "group", "having", "order", "limit"]
