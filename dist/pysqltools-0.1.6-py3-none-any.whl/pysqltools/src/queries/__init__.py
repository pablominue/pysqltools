"""
Queries Package. Contains everything SQL-Text query related
"""

from pysqltools.src.queries.query import Query, SQLString
