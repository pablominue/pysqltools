"""
Source code for the pysqltools package
"""

from pysqltools.src.queries.insert import generate_insert_query
from pysqltools.src.queries.query import Query, SQLString
