"""
Queries Package. Contains everything SQL-Text query related
"""

from pysqltools.src.SQL.query import Query, SQLString
